
package com.janitri.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

    @FindBy(id = "user_id")
    WebElement userIdInput;

    @FindBy(id = "password")
    WebElement passwordInput;

    @FindBy(id = "login_button")
    WebElement loginButton;

    @FindBy(id = "toggle_password_visibility")
    WebElement passwordToggle;

    WebDriver driver;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public boolean testLoginButtonDisabledWhenFieldAreEmpty() {
        return !loginButton.isEnabled();
    }

    public boolean testPasswordMaskedbutton() {
        return passwordInput.getAttribute("type").equals("password");
    }

    public String testInvalidLoginShowErrorMsg(String username, String password) {
        userIdInput.sendKeys(username);
        passwordInput.sendKeys(password);
        loginButton.click();
        WebElement error = driver.findElement(By.id("error_message"));
        return error.getText();
    }
}
