
package com.janitri.tests;

import org.testng.annotations.Test;
import com.janitri.pages.LoginPage;
import org.testng.Assert;

public class LoginTest extends BaseTest {

    @Test
    public void testLoginButtonDisabled() {
        LoginPage login = new LoginPage(driver);
        Assert.assertTrue(login.testLoginButtonDisabledWhenFieldAreEmpty());
    }

    @Test
    public void testPasswordMasked() {
        LoginPage login = new LoginPage(driver);
        Assert.assertTrue(login.testPasswordMaskedbutton());
    }

    @Test
    public void testInvalidLoginShowsError() {
        LoginPage login = new LoginPage(driver);
        String error = login.testInvalidLoginShowErrorMsg("invalidUser", "invalidPass");
        Assert.assertTrue(error.contains("Invalid credentials"));
    }
}
