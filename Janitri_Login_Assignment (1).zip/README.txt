
# Janitri Login Automation Assignment

- Java + Selenium WebDriver
- POM (Page Object Model) Pattern
- TestNG as Test Runner
- Manual Test Cases (.xlsx format)
- GitHub Submission
